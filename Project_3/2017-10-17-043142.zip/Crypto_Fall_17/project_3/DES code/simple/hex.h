#ifndef HEX_H
#define HEX_H

int hex_decode( const unsigned char *input, unsigned char **decoded );
void show_hex( const unsigned char *array, int length );

#endif
